/*
 * (c) 2013-2017 Rahmat M. Samik-Ibrahim
 * http://rahmatm.samik-ibrahim.vlsm.org/
 * This is free software.
 * REV00 Mon Sep 18 09:46:24 WIB 2017
 * START 2013
 */


#include <stdio.h> 
#include <stdlib.h> 

void main() { 
   int ii; 
   char buf[10];
   printf("Silakan isi: ");
   scanf("%s",buf);
   printf("Isi buffer = %s\n",buf);
}

