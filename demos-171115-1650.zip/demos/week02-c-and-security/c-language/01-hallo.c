/*
 * (c) 2016-2017 Rahmat M. Samik-Ibrahim
 * http://rahmatm.samik-ibrahim.vlsm.org/
 * This is free software.
 * REV00 Mon Sep 18 09:14:31 WIB 2017
 * START Tue Sep 13 11:51:21 WIB 2016
 */

#define STRING "This is a string\n"

#include <stdio.h>

void main() {
   printf(STRING);
}

