/*
 * (c) 2016-2017 Rahmat M. Samik-Ibrahim
 * http://rahmatm.samik-ibrahim.vlsm.org/
 * This is free software.
 * REV01 Mon Oct  2 16:21:15 WIB 2017
 * START Mon Sep 26 18:23:45 WIB 2016
 */

#include <stdio.h>

void main (void) {
   int cc; 
   while((cc = getchar()) != EOF) { 
      putchar(cc); 
   }
}

