REV01 Tue May  2 10:21:45 WIB 2017
START Mon Nov 21 14:39:48 WIB 2016
==================================

1. cd fuse-tutorial-2016-03-25
2. lynx index.html
3. make
4. cat example/ZREADME.txt

